return function(x, y)
    return not (x > 180 or x < -180 or y > 80)
end
