return require 'map_gen.maps.crash_site.presets.normal'
