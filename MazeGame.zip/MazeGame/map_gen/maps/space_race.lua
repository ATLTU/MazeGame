return require 'map_gen.maps.space_race.map_gen.map'
