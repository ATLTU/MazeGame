return require 'map_gen.maps.quadrants.scenario'
